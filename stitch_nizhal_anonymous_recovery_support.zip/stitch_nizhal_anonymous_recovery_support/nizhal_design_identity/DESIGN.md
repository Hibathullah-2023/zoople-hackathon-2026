---
name: Nizhal Design Identity
colors:
  surface: '#081425'
  surface-dim: '#081425'
  surface-bright: '#2f3a4c'
  surface-container-lowest: '#040e1f'
  surface-container-low: '#111c2d'
  surface-container: '#152031'
  surface-container-high: '#1f2a3c'
  surface-container-highest: '#2a3548'
  on-surface: '#d8e3fb'
  on-surface-variant: '#c6c6cd'
  inverse-surface: '#d8e3fb'
  inverse-on-surface: '#263143'
  outline: '#909097'
  outline-variant: '#45464d'
  surface-tint: '#bec6e0'
  primary: '#bec6e0'
  on-primary: '#283044'
  primary-container: '#0f172a'
  on-primary-container: '#798098'
  inverse-primary: '#565e74'
  secondary: '#4fdbc8'
  on-secondary: '#003731'
  secondary-container: '#04b4a2'
  on-secondary-container: '#003f38'
  tertiary: '#3cddc7'
  on-tertiary: '#003731'
  tertiary-container: '#001c18'
  on-tertiary-container: '#009182'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#dae2fd'
  primary-fixed-dim: '#bec6e0'
  on-primary-fixed: '#131b2e'
  on-primary-fixed-variant: '#3f465c'
  secondary-fixed: '#71f8e4'
  secondary-fixed-dim: '#4fdbc8'
  on-secondary-fixed: '#00201c'
  on-secondary-fixed-variant: '#005048'
  tertiary-fixed: '#62fae3'
  tertiary-fixed-dim: '#3cddc7'
  on-tertiary-fixed: '#00201c'
  on-tertiary-fixed-variant: '#005047'
  background: '#081425'
  on-background: '#d8e3fb'
  surface-variant: '#2a3548'
typography:
  headline-xl:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  xs: 4px
  sm: 12px
  md: 16px
  lg: 24px
  xl: 32px
  container-padding: 20px
  gutter: 16px
---

## Brand & Style

The design system is built upon the metaphor of the "Shadow"—a space of absolute privacy, protection, and quiet strength. It serves a dual purpose: providing a secure, anonymous channel for reporting and a nurturing, calm environment for rehabilitation. 

The visual style is a fusion of **Modern Minimalism** and **Tonal Depth**. It avoids the clinical coldness of traditional reporting apps in favor of a sophisticated, "dark mode first" aesthetic that feels both high-tech and human-centric. The interface prioritizes psychological safety, utilizing soft transitions and depth to guide users through sensitive workflows without feeling intrusive.

## Colors

The palette is anchored in deep, obsidian blues and charcoals to represent the "Shadow" aspect—anonymity and security. 

*   **Primary (Midnight Navy):** Used for the primary background and core identity, providing a grounded, secure base.
*   **Secondary & Tertiary (Healing Teal):** These soft greens and teals represent rehabilitation. They are used sparingly for action points, progress indicators, and "moments of hope" within the UI.
*   **Neutral (Slate/Charcoal):** Used for surface layering to create a sense of hierarchy and structural containment.
*   **Functional Colors:** Errors are soft corals rather than aggressive reds to maintain a calm atmosphere even during system warnings.

## Typography

This design system utilizes **Inter** for its exceptional legibility and neutral, systematic character. The typography is designed to be unobtrusive and highly readable, especially in low-light environments.

*   **Headlines:** Feature tighter letter spacing and heavier weights to provide a clear sense of location within the app.
*   **Body Copy:** Uses generous line heights to prevent visual fatigue during long reading sessions in the rehabilitation modules.
*   **Labels:** Employ a slight tracking increase and uppercase styling for secondary metadata to create a distinct visual contrast from primary content.

## Layout & Spacing

The layout follows a **Fluid Grid** model optimized for mobile devices, emphasizing a vertical rhythm based on an 8px square grid.

*   **Safe Zones:** Generous 20px side margins ensure that interactive elements are easily reachable and content doesn't feel cramped against the screen edges.
*   **Focus Areas:** For reporting workflows, the layout uses increased vertical padding (32px+) to isolate individual questions, reducing cognitive load and helping the user focus on one task at a time.
*   **Touch Targets:** All interactive elements maintain a minimum hit area of 44x44px, adhering to accessibility standards while maintaining a clean, spacious look.

## Elevation & Depth

To reflect the "Shadow" theme, the design system utilizes **Tonal Layers** and **Ambient Shadows** rather than traditional high-contrast shadows.

*   **Surface Hierarchy:** Depth is created by lightening the background hex code as elements "rise" closer to the user. Base background is the darkest, while cards and modals are slightly lighter charcoal.
*   **Subtle Inner Glows:** A 1px top border with low opacity (10-15%) is applied to cards to simulate a faint light source, giving elements a tangible, premium feel without breaking the dark aesthetic.
*   **Backdrop Blurs:** When modals or overlays are active, the content beneath is blurred (20px radius) to maintain a sense of space while focusing the user's attention entirely on the foreground task.

## Shapes

The shape language is consistently **Rounded**, striking a balance between professional discipline and approachable warmth. 

*   **Standard Elements:** Buttons and input fields use a 0.5rem (8px) radius to feel modern and safe.
*   **Containers:** Larger cards and bottom sheets use a 1rem (16px) radius to soften the overall appearance of the UI.
*   **Progress Indicators:** Use fully rounded (pill-shaped) caps to emphasize the fluid nature of the recovery journey.

## Components

### Buttons
Primary buttons utilize a subtle vertical gradient from the Tertiary to the Secondary teal, creating a "soft glow" effect. Secondary buttons are "ghost" style with a 1px slate border, ensuring they don't compete for attention.

### Input Fields
Inputs are designed with a "stealth" look—filled with a slightly lighter neutral shade than the background, with no borders until focused. Upon focus, a soft teal outer glow (shadow) indicates the active state.

### Incident Chips
Small, low-contrast badges used to categorize reports. They use a monochromatic scale (shades of navy/grey) to keep the information dense but visually quiet.

### Narrative Cards
For rehab support, cards feature a soft gradient background (Midnight to Deep Slate) to distinguish "Reading" content from "Action" content.

### Anonymity Toggle
A specialized component that uses a "shimmer" animation when active, providing visual confirmation that the user's identity is being masked by the system.